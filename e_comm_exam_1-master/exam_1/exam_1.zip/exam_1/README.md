# exam_1

A new Flutter project.

E-Commerce App


It has many screens link below :
- AllHomePage
- DetailsPage
- CartPage

List of Functionalities :

- Display all Product in all product Page
- Show category wise products in allHomePage
- Display a tapped product in detailPage
- store a product  which you added to favorite
- Display stored/added product in favoritepage
