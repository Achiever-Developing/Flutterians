import 'package:flutter/material.dart';

class MyRoutes {
  static String splashscreens = "/";
  static String homePage = 'home_page';
  static String detailPage = "detail_page";
  static String cartPage = "cart_page";
}
