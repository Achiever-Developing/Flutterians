import 'package:carousel_slider/carousel_slider.dart';
import 'package:exam_1/utils/producte_utils.dart';
import 'package:exam_1/utils/routes.dart';
import 'package:exam_1/views/componets/category_view.dart';
import 'package:flutter/material.dart';

final List<String> imgList = [
  "assets/images/category/jwellery.jpeg",
  "assets/images/category/image1.jpeg",
  "assets/images/category/image2.jpeg",
  "assets/images/category/image3.jpeg",
  "assets/images/category/image4.jpeg",
];

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Home Page",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w600,
            fontSize: 25,
          ),
        ),
        backgroundColor: const Color(0xFF5F6F52),
        actions: [
          const Icon(
            Icons.search_rounded,
            color: Colors.white,
          ),
          const SizedBox(
            width: 10,
          ),
          IconButton(
              onPressed: () {
                Navigator.of(context).pushNamed(MyRoutes.cartPage);
              },
              icon: const Icon(
                Icons.shopping_cart,
                color: Colors.white,
              ))
        ],
      ),
      body: Stack(
        children: [
          Container(
            height: double.infinity,
            width: double.infinity,
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage(
                  "assets/images/category/whitmarble.jpeg",
                ),
                fit: BoxFit.fill,
              ),
            ),
          ),
          SingleChildScrollView(
            child: Padding(
              padding: EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Giva Fashion",
                    style: TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                        color: Colors.black),
                  ),
                  Padding(
                      padding: EdgeInsets.all(10),
                      child: CarouselSlider(
                        items: [
                          ...List.generate(
                            imgList.length,
                            (index) => Container(
                              decoration: BoxDecoration(
                                  image: DecorationImage(
                                      image: AssetImage(
                                imgList[index],
                              ))),
                            ),
                          ),
                        ],
                        options: CarouselOptions(
                          height: 250,
                          autoPlay: true,
                        ),
                      )),
                  Padding(
                    padding: EdgeInsets.all(10),
                    child: Expanded(
                      child: GestureDetector(
                        child: SingleChildScrollView(
                          child: Column(
                            children: allCategories
                                .map(
                                  (e) => CategoryView(
                                    category: e,
                                    context: context,
                                  ),
                                )
                                .toList(),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
